# react-playlist
All the course files for the Net Ninja React tutorial playlist on YouTube

# How to use these files
Each of the branches in this repo refers to the starting point of a particular lesson in the playlist. For example, the lesson-3 branch is the starting code for the lesson 3 video. Just checkout the branch / lesson that you need.

Be sure to run an 'npm install' to install any dependencies.
